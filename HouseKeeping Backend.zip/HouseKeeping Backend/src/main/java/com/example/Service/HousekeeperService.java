package com.example.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.HouseKeeper;
import com.example.dao.HouseKeeperRepo;

@Service
public class HousekeeperService {

	@Autowired
	private HouseKeeperRepo houseKeeperRepo;

	public HouseKeeper registerWorker(HouseKeeper houseKeeper) {
		// TODO Auto-generated method stub
		return this.houseKeeperRepo.saveAndFlush(houseKeeper);
	}

	public List<HouseKeeper> getWorkerByFloor(int floor,String hostel) {
		// TODO Auto-generated method stub
		 List<HouseKeeper> findByFloor = this.houseKeeperRepo.findByFloor(floor);
		return findByFloor.stream().filter(item -> item.getHostel().equals(hostel)).collect(Collectors.toList());
	}

	public HouseKeeper getWorkerById(int workerId) {
		// TODO Auto-generated method stub
		 Optional<HouseKeeper> findById = this.houseKeeperRepo.findById(workerId);
		 return findById.get();
	}
}
