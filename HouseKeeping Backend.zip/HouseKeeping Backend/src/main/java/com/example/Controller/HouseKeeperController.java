package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.HouseKeeper;
import com.example.Service.HousekeeperService;

@RestController
@CrossOrigin("*")
public class HouseKeeperController {

	@Autowired
	private HousekeeperService housekeeperService;
	
	@PostMapping("/registerWorker/{hostel}")
	public HouseKeeper registerWorker(@RequestBody HouseKeeper houseKeeper,@PathVariable("hostel") String hostel) {
		houseKeeper.setHostel(hostel);
		return this.housekeeperService.registerWorker(houseKeeper);	
	}
	
	@GetMapping("/getHouseKeeperByFloor/{floor}/{hostel}")
	public List<HouseKeeper> getWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel){
		return this.housekeeperService.getWorkerByFloor(floor,hostel);
	}
}
